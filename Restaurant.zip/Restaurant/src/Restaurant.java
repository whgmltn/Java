import java.io.*;
import java.util.*;

// Restaurant 클래스(super)
public class Restaurant implements Serializable {
	// Menu 객체들로 이루어진 리스트
	private ArrayList<Menu> menus = new ArrayList<Menu>();
	// Table 객체들로 이루어진 리스트
	private ArrayList<Table> tables = new ArrayList<Table>();
	// 매출액 변수
	private int amount=0;
	
	// Restaurant 기본 생성자 함수
	public Restaurant() {}
	
	// ObjectInputStream을 변수로 받는 Restaurant 생성자 함수(생성 시 파일 불러오기.)
	public Restaurant(ObjectInputStream in) throws Exception {
		this.readObject(in);
	}
		
	// DataInputStream을 변수로 받는 Restaurant 생성자 함수(생성 시 파일 불러오기.)
	public Restaurant(DataInputStream in) throws Exception {
		this.readRestaurant(in);
	}
	
	// menus 접근자
	ArrayList<Menu> getMenus() {
		return menus;
	}
	// tables 접근자
	ArrayList<Table> getTables() {
		return tables;
	}
	// menus 리스트 사이즈 접근자
	int getMenuSize() {
		return menus.size();
	}
	// tables 리스트 사이즈 접근자
	int getTableSize() {
		return tables.size();
	}
	// amount 접근자
	int getAmount() {
		return amount;
	}
	
	// 메뉴 객체 탐색
	public int searchMenu(Menu target) {
		int tIndex = menus.indexOf(target);	// 찾으려는 객체의 인덱스 값, 없다면 -1을 반환함. 이를 tIndex 변수에 저장
		return tIndex;	// tIndex 반환
	} 
		
	// 테이블 객체 탐색
	public int searchTable(Table target) {
		int tIndex = tables.indexOf(target);	// 찾으려는 객체의 인덱스 값, 없다면 -1을 반환함. 이를 tIndex 변수에 저장
		return tIndex;	// tIndex 반환
	}
	
	// 메뉴 객체 추가
	public void addMenu(Menu m) throws Exception {
		// 추가하려는 메뉴가 원래 없던 메뉴일 경우
		if (searchMenu(m)==-1) {
			menus.add(m);	// menus에서 비어있는 첫번째 인덱스에 메뉴 추가
		}
		// 추가하려는 메뉴가 원래 있던 메뉴일 경우
		else {
			throw new Exception("The menu already exists");
		}
	}
	
	// 테이블 객체 추가
	public void addTable(Table t) throws Exception {
		// 추가하려는 테이블이 원래 없던 테이블일 경우
		if (searchTable(t)==-1) {
			tables.add(t);	// tables에서 비어있는 첫번째 인덱스에 메뉴 추가
		}
		// 추가하려는 테이블이 원래 있던 테이블일 경우
		else {
			throw new Exception("The table already exists");
		}
	}
	
	// 매출액 값 추가
	public void addAmount(int paid) {
		amount += paid;
	}
 	
	// 메뉴 객체 삭제
	public void deleteMenu(Menu m) throws Exception{
		// 삭제하려는 메뉴가 있는 경우
		if (searchMenu(m) != -1) {
			menus.remove(m);
		}
		// 삭제하려는 메뉴가 없는 경우
		else {
			throw new Exception("The menu does not exist");	// 삭제하려는 메뉴가 없는 경우 예외 발생
		}
	}

	// 테이블 객체 삭제
	public void deleteTable(Table t) throws Exception {
		// 삭제하려는 메뉴가 있는 경우
		if (searchTable(t) != -1) {
			tables.remove(t);
		}
		// 삭제하려는 메뉴가 없는 경우
		else {
			throw new Exception("The table does not exist");	// 삭제하려는 메뉴가 없는 경우 예외 발생
		}
	}

	// menu 정보와 table 정보 저장
	public void writeRestaurant(DataOutputStream out) throws Exception {		
		
		out.writeInt(menus.size());	// 메뉴 수 
		
		// 반복을 통해 menus[]에 저장된 메뉴 객체들의 요소를 프리미티브 타입으로 파일에 출력
		for (int i=0; i<menus.size(); i++) {
			menus.get(i).writeMenu(out);
		}
		
		out.writeInt(menus.size());	// 메뉴 수 
		
		// 반복을 통해 tables[]에 저장된 테이블 객체들의 요소를 프리미티브 타입으로 파일에 출력
		for (int i=0; i<tables.size(); i++) {
			tables.get(i).writeTable(out);
		}
		
		out.writeInt(amount);	// 총 매출액을 파일에 출력
		
	}

	// 저장된 menu 정보와 table 정보 입력 
	public void readRestaurant(DataInputStream in) throws Exception {
		
		int menuSize = in.readInt();	// 메뉴 수 
		// 반복을 통해 파일에 저장된 메뉴 객체 정보를 새로운 메뉴 객체를 생성하여 정보 입력 후 menus[]에 추가
		for (int i=0; i< menuSize; i++) {
			Menu menu = new Menu();	// 메뉴 객체 생성
			menu.readMenu(in);	// 메뉴 정보 입력
			menus.add(menu);	// 메뉴 배열에 추가
		}
		
		int tableSize = in.readInt();	// 테이블 수 
		
		// 반복을 통해 파일에 저장된 테이블 객체 정보를 새로운 테이블 객체를 생성하여 tables[]에 입력
		for (int i=0; i< tableSize; i++) {
			Table table = new Table();	// 테이블 객체 생성
			table.readTable(in);	// 테이블 정보 입력
			tables.add(table);	// 테이블 배열에 추가
		}
		
		amount = in.readInt();	// 파일에 저장된 총 매출액을 amount 변수에 입력
		
	}
	
	// 직렬화
	void writeObject(ObjectOutputStream oop) throws Exception{
		oop.writeObject(menus); 	// menus 직렬화
		oop.writeObject(tables);	// tables 직렬화
		oop.writeInt(amount);	// 기본 객체 직렬화
	}
		
	// 역직렬화
	void readObject(ObjectInputStream oip) throws Exception{
		menus = (ArrayList<Menu>) oip.readObject();	// menus 역직렬화
		tables = (ArrayList<Table>) oip.readObject();	// tables 역직렬화
		amount = oip.readInt();	// 기본 객체 역직렬화
	}
		
	
	// 메뉴 객체를 오더 객체로 변환
	public Order menuToOrder(Menu m) {
		Order ord;
		ord = new Order(m.getMenuName(), m.getPrice());
		return ord;
	}
	
	// 계산
	public int pay(Table t) {
		int paid = t.outTable();
		addAmount(paid);
		return paid;
	}
}
