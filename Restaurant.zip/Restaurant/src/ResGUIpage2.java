import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTabbedPane;
import javax.swing.BoxLayout;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.GridBagLayout;
import javax.swing.JScrollPane;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.JButton;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;
import java.awt.event.ActionEvent;
import javax.swing.JSpinner;
import javax.swing.SpinnerListModel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.ScrollPaneConstants;
import java.awt.Font;
import java.io.*;


public class ResGUIpage2 extends JFrame {
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTable table;	// 테이블 리스트 테이블
	private JTable table_1;	// 메뉴 리스트 테이블
	private JTextField textField_1;
	private JButton addTableB;
	private JButton fixTableB;
	private JButton deleteTableB;
	private JButton saveTableB;
	private JButton findTableB;
	private Button runModeB;
	private JButton addMenuB;
	private JButton fixMenuB;
	private JButton deleteMenuB;
	private JButton saveMenuB;
	private JButton findMenuB;
	private ArrayList<Menu> menus;
	private ArrayList<Table> tables;
	private DefaultTableModel modelT;
	private DefaultTableModel modelM;
	private ObjectOutputStream out;
	private ObjectInputStream in;
	private Restaurant bab;
	private boolean editModelT;
	private boolean editModelM;
	private boolean deleteT;
	private boolean deleteM;
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ResGUIpage2 frame = new ResGUIpage2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ResGUIpage2() {	
		String fileName = "restaurant.dat";	// 데이터 입출력할 파일명
		try {
			in = new ObjectInputStream(new FileInputStream(fileName));
			bab = new Restaurant(in);	// ObjectInputStream을 변수로 받는 Restaurant 객체 생성
		}
		catch(FileNotFoundException fnfe) {	// 처음 시작하는 경우 등 파일이 없을 때
			bab = new Restaurant();	// 데이터를 불러오지 않는 기본 생성자 함수를 사용해 Restaurant 객체 생성
		}
		catch(Exception e1) {	
			bab = new Restaurant();	// 데이터를 불러오지 않는 기본 생성자 함수를 사용해 Restaurant 객체 생성
		} finally {
			try {
				in.close();	// 스트림 닫기
			} catch (Exception e1) {}
		}
		
		// 윈도우 리스너 객체 생성
        MyWindowListener listener = new MyWindowListener();
        // 윈도우에 리스너 등록
        addWindowListener(listener);
		
		tables = bab.getTables();
		menus = bab.getMenus();
		setTitle("Restaurant-관리자 모드");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1026, 561);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[] {0};
		gbl_contentPane.rowHeights = new int[] {0};
		gbl_contentPane.columnWeights = new double[]{1.0, 0.0};
		gbl_contentPane.rowWeights = new double[]{1.0, 0.0};
		contentPane.setLayout(gbl_contentPane);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		GridBagConstraints gbc_tabbedPane = new GridBagConstraints();
		gbc_tabbedPane.gridwidth = 2;
		gbc_tabbedPane.fill = GridBagConstraints.BOTH;
		gbc_tabbedPane.insets = new Insets(0, 0, 5, 0);
		gbc_tabbedPane.gridx = 0;
		gbc_tabbedPane.gridy = 0;
		contentPane.add(tabbedPane, gbc_tabbedPane);
		
		JPanel panel = new JPanel();
		tabbedPane.addTab("Table", null, panel, null);
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWidths = new int[]{770, 200, 0};
		gbl_panel.rowHeights = new int[]{0, 0, 0};
		gbl_panel.columnWeights = new double[]{1.0, 1.0, Double.MIN_VALUE};
		gbl_panel.rowWeights = new double[]{0.0, 1.0, Double.MIN_VALUE};
		panel.setLayout(gbl_panel);
		
		JPanel panel_3 = new JPanel();
		GridBagConstraints gbc_panel_3 = new GridBagConstraints();
		gbc_panel_3.fill = GridBagConstraints.HORIZONTAL;
		gbc_panel_3.insets = new Insets(0, 0, 5, 5);
		gbc_panel_3.gridx = 0;
		gbc_panel_3.gridy = 0;
		panel.add(panel_3, gbc_panel_3);
		GridBagLayout gbl_panel_3 = new GridBagLayout();
		gbl_panel_3.columnWidths = new int[]{75, 50, 75, 0};
		gbl_panel_3.rowHeights = new int[]{23, 0};
		gbl_panel_3.columnWeights = new double[]{0.0, 1.0, 0.0, Double.MIN_VALUE};
		gbl_panel_3.rowWeights = new double[]{0.0, Double.MIN_VALUE};
		panel_3.setLayout(gbl_panel_3);
		
		JLabel lblNewLabel = new JLabel("테이블 명");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.fill = GridBagConstraints.BOTH;
		gbc_lblNewLabel.insets = new Insets(0, 0, 0, 5);
		gbc_lblNewLabel.gridx = 0;
		gbc_lblNewLabel.gridy = 0;
		panel_3.add(lblNewLabel, gbc_lblNewLabel);
		
		textField = new JTextField();
		GridBagConstraints gbc_textField = new GridBagConstraints();
		gbc_textField.fill = GridBagConstraints.BOTH;
		gbc_textField.insets = new Insets(0, 0, 0, 5);
		gbc_textField.gridx = 1;
		gbc_textField.gridy = 0;
		panel_3.add(textField, gbc_textField);
		textField.setColumns(10);
		
		JButton findTableB = new JButton("찾기");
		GridBagConstraints gbc_findTableB_1 = new GridBagConstraints();
		gbc_findTableB_1.fill = GridBagConstraints.BOTH;
		gbc_findTableB_1.gridx = 2;
		gbc_findTableB_1.gridy = 0;
		panel_3.add(findTableB, gbc_findTableB_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		GridBagConstraints gbc_scrollPane = new GridBagConstraints();
		gbc_scrollPane.insets = new Insets(0, 0, 5, 5);
		gbc_scrollPane.fill = GridBagConstraints.BOTH;
		gbc_scrollPane.gridx = 0;
		gbc_scrollPane.gridy = 1;
		panel.add(scrollPane, gbc_scrollPane);
		
		editModelT = false;
		deleteT = false;
		modelT = new DefaultTableModel(new Object[][] {{null, null, null},},new String[] {"테이블 명", "수용 인원", "이용 가능 여부"}){
			Class[] columnTypes = new Class[] {
					String.class, Integer.class, Boolean.class
				};
				public Class getColumnClass(int columnIndex) {
					return columnTypes[columnIndex];
				}
				public boolean isCellEditable(int row, int column) {
			        return editModelT; // 셀을 편집하지 못하도록 설정
			    }
			};
		table = new JTable(modelT);
		table.setRowHeight(30);
		table.setBorder(null);
		int tableSize=bab.getTableSize();
		for(int i=0; i<tableSize; i++) {
			Table t = tables.get(i);
			modelT.insertRow(i,new Object[]{t.getTableName(), t.getMember(), t.getAvailable()});
		}
		table.setFont(new Font("함초롬돋움", Font.PLAIN, 17));
		scrollPane.setViewportView(table);
		
		JPanel panel_2 = new JPanel();
		GridBagConstraints gbc_panel_2 = new GridBagConstraints();
		gbc_panel_2.gridheight = 2;
		gbc_panel_2.insets = new Insets(0, 0, 5, 0);
		gbc_panel_2.fill = GridBagConstraints.BOTH;
		gbc_panel_2.gridx = 1;
		gbc_panel_2.gridy = 0;
		panel.add(panel_2, gbc_panel_2);
		panel_2.setLayout(new GridLayout(0, 1, 0, 0));
		
		fixTableB = new JButton("수정");
		fixTableB.addActionListener(new ButtonListener());
		fixTableB.setFont(new Font("함초롬돋움", Font.PLAIN, 15));
		panel_2.add(fixTableB);
		
		addTableB = new JButton("추가");
		addTableB.addActionListener(new ButtonListener());
		addTableB.setFont(new Font("함초롬돋움", Font.PLAIN, 15));
		panel_2.add(addTableB);
		
		deleteTableB = new JButton("삭제");
		deleteTableB.addActionListener(new ButtonListener());
		deleteTableB.setFont(new Font("함초롬돋움", Font.PLAIN, 15));
		panel_2.add(deleteTableB);
		
		saveTableB = new JButton("저장");
		saveTableB.addActionListener(new ButtonListener());
		saveTableB.setFont(new Font("함초롬돋움", Font.PLAIN, 15));
		panel_2.add(saveTableB);
		
		JPanel panel_1 = new JPanel();
		tabbedPane.addTab("Menu", null, panel_1, null);
		GridBagLayout gbl_panel_1 = new GridBagLayout();
		gbl_panel_1.columnWidths = new int[]{770, 200, 0};
		gbl_panel_1.rowHeights = new int[]{0, 0, 0};
		gbl_panel_1.columnWeights = new double[]{1.0, 1.0, Double.MIN_VALUE};
		gbl_panel_1.rowWeights = new double[]{0.0, 1.0, Double.MIN_VALUE};
		panel_1.setLayout(gbl_panel_1);
		
		JPanel panel_6 = new JPanel();
		GridBagConstraints gbc_panel_6 = new GridBagConstraints();
		gbc_panel_6.fill = GridBagConstraints.HORIZONTAL;
		gbc_panel_6.insets = new Insets(0, 0, 5, 5);
		gbc_panel_6.gridx = 0;
		gbc_panel_6.gridy = 0;
		panel_1.add(panel_6, gbc_panel_6);
		GridBagLayout gbl_panel_6 = new GridBagLayout();
		gbl_panel_6.columnWidths = new int[]{75, 50, 75, 0};
		gbl_panel_6.rowHeights = new int[]{23, 0};
		gbl_panel_6.columnWeights = new double[]{0.0, 1.0, 0.0, Double.MIN_VALUE};
		gbl_panel_6.rowWeights = new double[]{0.0, Double.MIN_VALUE};
		panel_6.setLayout(gbl_panel_6);
		
		JLabel label = new JLabel("메뉴명");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		GridBagConstraints gbc_label = new GridBagConstraints();
		gbc_label.fill = GridBagConstraints.BOTH;
		gbc_label.insets = new Insets(0, 0, 0, 5);
		gbc_label.gridx = 0;
		gbc_label.gridy = 0;
		panel_6.add(label, gbc_label);
		
		textField_1 = new JTextField();
		GridBagConstraints gbc_textField_1 = new GridBagConstraints();
		gbc_textField_1.fill = GridBagConstraints.BOTH;
		gbc_textField_1.insets = new Insets(0, 0, 0, 5);
		gbc_textField_1.gridx = 1;
		gbc_textField_1.gridy = 0;
		panel_6.add(textField_1, gbc_textField_1);
		textField_1.setColumns(10);
		
		findMenuB = new JButton("찾기");
		findMenuB.addActionListener(new ButtonListener());
		GridBagConstraints gbc_findMenuB = new GridBagConstraints();
		gbc_findMenuB.fill = GridBagConstraints.BOTH;
		gbc_findMenuB.gridx = 2;
		gbc_findMenuB.gridy = 0;
		panel_6.add(findMenuB, gbc_findMenuB);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		GridBagConstraints gbc_scrollPane_1 = new GridBagConstraints();
		gbc_scrollPane_1.insets = new Insets(0, 0, 5, 5);
		gbc_scrollPane_1.fill = GridBagConstraints.BOTH;
		gbc_scrollPane_1.gridx = 0;
		gbc_scrollPane_1.gridy = 1;
		panel_1.add(scrollPane_1, gbc_scrollPane_1);
		
		editModelM = false;
		deleteM = false;
		String colNamesM[]= {"메뉴 명","메뉴 가격"};
		modelM = new DefaultTableModel(new Object[][] {{null, null},},colNamesM){
			Class[] columnTypes = new Class[] {
					String.class, Integer.class
				};
				public Class getColumnClass(int columnIndex) {
					return columnTypes[columnIndex];
				}
				public boolean isCellEditable(int row, int column) {
			        return editModelM; // 셀을 편집하지 못하도록 설정
			    }
			};
		table_1 = new JTable(modelM);
		table_1.setRowHeight(30);
		table_1.setFont(new Font("함초롬돋움", Font.PLAIN, 17));
		int menuSize=bab.getMenuSize();
		for(int i=0; i<menuSize; i++) {
			Menu m = menus.get(i);
			modelM.insertRow(i,new Object[]{m.getMenuName(), m.getPrice()});
		}
		scrollPane_1.setViewportView(table_1);
		
		JPanel panel_5 = new JPanel();
		GridBagConstraints gbc_panel_5 = new GridBagConstraints();
		gbc_panel_5.gridheight = 2;
		gbc_panel_5.insets = new Insets(0, 0, 5, 0);
		gbc_panel_5.fill = GridBagConstraints.BOTH;
		gbc_panel_5.gridx = 1;
		gbc_panel_5.gridy = 0;
		panel_1.add(panel_5, gbc_panel_5);
		panel_5.setLayout(new GridLayout(0, 1, 0, 0));
		
		addMenuB = new JButton("추가");
		addMenuB.setFont(new Font("함초롬돋움", Font.PLAIN, 15));
		addMenuB.addActionListener(new ButtonListener());
		
		fixMenuB = new JButton("수정");
		fixMenuB.setFont(new Font("함초롬돋움", Font.PLAIN, 15));
		fixMenuB.addActionListener(new ButtonListener());
		panel_5.add(fixMenuB);
		panel_5.add(addMenuB);
		
		deleteMenuB = new JButton("삭제");
		deleteMenuB.setFont(new Font("함초롬돋움", Font.PLAIN, 15));
		deleteMenuB.addActionListener(new ButtonListener());
		panel_5.add(deleteMenuB);
		
		saveMenuB = new JButton("저장");
		saveMenuB.setFont(new Font("함초롬돋움", Font.PLAIN, 15));
		saveMenuB.addActionListener(new ButtonListener());
		panel_5.add(saveMenuB);
		
		runModeB = new Button("운영모드");
		runModeB.setFont(new Font("함초롬돋움", Font.BOLD, 10));
		runModeB.addActionListener(new ButtonListener());
		
		int amount = bab.getAmount();
		JLabel lblNewLabel_1 = new JLabel("총 매출액: "+amount+"원");
		lblNewLabel_1.setFont(new Font("함초롬돋움", Font.BOLD, 14));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.LEFT);
		GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
		gbc_lblNewLabel_1.fill = GridBagConstraints.HORIZONTAL;
		gbc_lblNewLabel_1.anchor = GridBagConstraints.NORTH;
		gbc_lblNewLabel_1.insets = new Insets(0, 15, 0, 0);
		gbc_lblNewLabel_1.gridx = 0;
		gbc_lblNewLabel_1.gridy = 1;
		contentPane.add(lblNewLabel_1, gbc_lblNewLabel_1);
		GridBagConstraints gbc_btnNewButton_5 = new GridBagConstraints();
		gbc_btnNewButton_5.anchor = GridBagConstraints.NORTH;
		gbc_btnNewButton_5.gridx = 1;
		gbc_btnNewButton_5.gridy = 1;
		contentPane.add(runModeB, gbc_btnNewButton_5);
		
	}

	class MyWindowListener extends WindowAdapter{
		private SaveExceptionFrame saveFrame; // SaveExcepitonFrame 객체 참조 변수

	    public MyWindowListener() {
	    	try {
				out = new ObjectOutputStream(new FileOutputStream("restaurant.dat"));	//"restaurant.dat" 파일에 저장할 예정
			} catch(Exception e1){
				try {
					out.close();
				} catch (IOException ioe) {}
			}
	        saveFrame = new SaveExceptionFrame(bab,out); // 생성자에서 SaveExcepitonFrame 객체 초기화
	    }

	    public void windowClosing(WindowEvent e) {
	    	setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
	        saveFrame.setLocationRelativeTo(ResGUIpage2.this);
	        saveFrame.addWindowListener(new WindowAdapter() {
                public void windowClosed(WindowEvent e) {
                    ResGUIpage2.this.dispose(); // ResGUIpage2 윈도우를 닫음
                }
            });
	        saveFrame.setVisible(true); // 윈도우가 닫힐 때 SaveExcepitonFrame을 보이도록 함
	        
	    }
	}

	//버튼 동작
	class ButtonListener implements ActionListener {

		public void actionPerformed(ActionEvent e) {
			if (e.getSource() == addTableB) {
				int rowCnt = modelT.getRowCount();
				if (rowCnt >= 1) {
					String Tname = null;
					int Tmember = 0;
					Boolean Tavailable= true;
					try {
						Tname = (String) modelT.getValueAt(rowCnt-1, 0);
						Tmember = (int) modelT.getValueAt(rowCnt-1, 1);
						Tavailable = (Boolean) modelT.getValueAt(rowCnt-1, 2);
					}catch(Exception e1){
						ExceptionFrame ef = new ExceptionFrame(e1);
						ef.setLocationRelativeTo(ResGUIpage2.this);
						ef.setVisible(true);
					}
					if (Tname != null) {
						Table t = new Table(Tname, Tmember, Tavailable);
						try {
							bab.addTable(t);
							modelT.addRow(new Object[]{null, null, null});
						}catch(Exception e1) {
							ExceptionFrame ef = new ExceptionFrame(e1);
							ef.setLocationRelativeTo(ResGUIpage2.this);
							ef.setVisible(true);
						}
					}
				}else {
					modelT.addRow(new Object[]{null, null, null});	
				}
				modelT.fireTableDataChanged();
			}
			else if (e.getSource() == fixTableB) {
				editModelT = !editModelT;
				deleteT = !deleteT;
				modelT.fireTableDataChanged();
			}
			else if (e.getSource() == deleteTableB) {
				if(deleteT==false) {
					return;
				}
				int row = table.getSelectedRow();
				if (row == -1) {
					return;
				}
				try {
					String TName= (String)table.getValueAt(row, 0);
					bab.deleteTable(new Table(TName));
				}catch(Exception e1) {
					ExceptionFrame ef = new ExceptionFrame(e1);
					ef.setLocationRelativeTo(ResGUIpage2.this);
					ef.setVisible(true);
				}
				modelT.removeRow(row);
				
			}
			else if (e.getSource() == findTableB) {
			    String searchMenu = textField.getText(); // 검색할 텍스트를 소문자로 변환
			    if (searchMenu.isEmpty()) {
			    	table.setSelectionBackground(null);
			    }
			    int row = bab.searchTable(new Table(searchMenu));
			    if(row != -1) {
			    	table.setRowSelectionInterval(row, row);
			    	table.setSelectionBackground(Color.YELLOW);
			    }
            }
			
			else if (e.getSource() == saveTableB || e.getSource() == saveMenuB) {
				try {
					out = new ObjectOutputStream(new FileOutputStream("restaurant.dat"));	//"restaurant.dat" 파일에 저장할 예정
					bab.writeObject(out);	// 데이터들을 파일에 저장
				} catch(Exception e1){
					ExceptionFrame ef = new ExceptionFrame(e1);
					ef.setLocationRelativeTo(ResGUIpage2.this);
					ef.setVisible(true);
				} finally {
				    try {
				        if (out != null) {
				            out.close();
				        }
				    } catch (IOException ioe) {
				    	ExceptionFrame ef = new ExceptionFrame(ioe);
						ef.setLocationRelativeTo(ResGUIpage2.this);
						ef.setVisible(true);
				        // 예외 처리
				    }
				}
            }
			
			else if (e.getSource() == addMenuB) {
				int rowCnt = modelM.getRowCount();
				modelM.isCellEditable(rowCnt, ABORT);
				if (rowCnt >= 1) {
					String Mname = null;
					int Mprice = 0;
					try {
						Mname = (String) modelM.getValueAt(rowCnt-1, 0);
						Mprice = (int) modelM.getValueAt(rowCnt-1, 1);
					} catch(Exception e1) {
					}
					if (Mname != null) {
						Menu m = new Menu(Mname, Mprice);
						try {
							bab.addMenu(m);;
							modelM.addRow(new Object[]{null, null});
						}catch(Exception e1) {
							ExceptionFrame ef = new ExceptionFrame(e1);
							ef.setLocationRelativeTo(ResGUIpage2.this);
							ef.setVisible(true);
						}	
					}
				}else {
					modelM.addRow(new Object[]{null, null, null});	
				}
				modelM.fireTableDataChanged();
			}
			else if (e.getSource() == fixMenuB) {
				editModelM = !editModelM;
				deleteM =!deleteM;
				modelM.fireTableDataChanged();
			}
				
			else if (e.getSource() == deleteMenuB) {
				if(deleteM == false) {
					return;
				}
				int row = table_1.getSelectedRow();
				if (row == -1) {
					return;
				}
				modelM = (DefaultTableModel) table_1.getModel();
				try {
					String MName= (String)table_1.getValueAt(row, 0);
					bab.deleteMenu(new Menu(MName));
				}catch(Exception e1) {
					ExceptionFrame ef = new ExceptionFrame(e1);
					ef.setLocationRelativeTo(ResGUIpage2.this);
					ef.setVisible(true);
				}
				modelM.removeRow(row);
			}
			
			else if (e.getSource() == findMenuB) {
			    String searchMenu = textField_1.getText(); // 검색할 텍스트를 소문자로 변환
			    if (searchMenu.isEmpty()) {
			    	table_1.setSelectionBackground(null);
			    }
			    int row = bab.searchMenu(new Menu(searchMenu));
			    if(row != -1) {
			    	table_1.setRowSelectionInterval(row, row);
			    	table_1.setSelectionBackground(Color.YELLOW);
			    }
            }
			
			else if (e.getSource()==runModeB) {
				try {
					out = new ObjectOutputStream(new FileOutputStream("restaurant.dat"));	//"restaurant.dat" 파일에 저장할 예정
					bab.writeObject(out);	// 데이터들을 파일에 저장
				} catch(Exception e1){
					ExceptionFrame ef = new ExceptionFrame(e1);
					ef.setLocationRelativeTo(ResGUIpage2.this);
					ef.setVisible(true);
				} finally {
				    try {
				        if (out != null) {
				            out.close();
				        }
				    } catch (IOException ioe) {
				    	ExceptionFrame ef = new ExceptionFrame(ioe);
						ef.setLocationRelativeTo(ResGUIpage2.this);
						ef.setVisible(true);
				        // 예외 처리
				    }
				}
				ResGUIpage2.this.dispose();
				ResGui runMode = new ResGui();
				runMode.setVisible(true);			
			}

		}
	}	
}
