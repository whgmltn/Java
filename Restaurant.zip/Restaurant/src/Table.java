import java.io.*;
import java.util.*;

// Table 클래스
public class Table implements Serializable{
	private String tableName;	// 테이블 번호 변수
	private int member=0;	// 수용 가능 인원 변수
	private boolean available = true;	// 테이블 이용 가능 여부 변수
	private ArrayList<Order> orders = new ArrayList<Order>();	// 주문 내역 리스트 변수
	
	Table(){}
	
	// 테이블 생성자
	Table(String tableName){
		this.tableName = tableName;
	}
		
	// 테이블 생성자
	Table(String tableName, int member, boolean available){
		this.tableName = tableName;
		this.member = member;
		this.available = available;
	}
			
	// 테이블명 접근자
	String getTableName() {
		return tableName;
	}
	
	// 수용 가능 인원 접근자
	int getMember() {
		return member;
	}
	
	// 이용 가능 여부 접근자
	boolean getAvailable() {
		return available;
	}
	
	// orderLast 접근자
	int getOrderSize() {
		return orders.size();
	}
		
	// 테이블명 설정자
	void setName(String tableName) {
		this.tableName = tableName;
	}
	
	// 수용 가능 인원 설정자
	void setMember(int member) {
		this.member = member;
	}
	
	// 이용 가능 여부 설정자
	void setAvailable(boolean tf) {
		this.available = tf;
	}
			
	// 주문 추가 함수
	void addOrder(Order o, int n){
		if(getAvailable() ==true) {
			this.inTable();
		}
		// 이전에 주문했던 메뉴가 아닐 경우
		if(searchOrder(o) == -1) {	
			orders.add(o);	// orders에 order라는 객체 추가
		}
		o.addOrderCount(n);	//order 객체의 orderCount를 n만큼 증가
	}
	
	// 메뉴 객체 탐색
	public int searchOrder(Order target) {
		int tIndex = orders.indexOf(target);	// 찾으려는 객체의 인덱스 값, 없다면 -1을 반환함. 이를 tIndex 변수에 저장
		return tIndex;	// tIndex 반환
	}
	
	// 테이블에 손님이 들어온 경우
	int inTable() {
		if (available == true) {
			available = false;	// 이용 불가능으로 변경
			return 0;
		}
		else {
			return -1;
		}
	}
	
	// 손님이 계산을 마치고 나갈 경우
	int outTable() {
		int paid = getTotal();	// paid 변수에 total 값을 대입(total은 0으로 초기화할 것이기 때문에)
		available = true;	// 이용 가능으로 변경	 
		orders.clear(); // ordes 리스트 초기화
		return paid;
	}
	
	// 주문 내역을 보여주는 함수
	ArrayList<Order> getOrders() {
		return orders;
	}
	
	// total 접근자
	int getTotal() {
		int total = 0;
		for (int i=0; i < orders.size(); i++) {
			total += orders.get(i).getOrderPay();	// orders의 i번째 인덱스에 있는 Order 객체의 orderPay를 토탈 값에 더함
		}
		return total;
	}

	// 오더 객체를 파일에 출력
	void writeOrder(DataOutputStream wo) throws Exception{
		wo.writeInt(orders.size());	// 오더 수 
		// 반복을 통해 menus[]에 저장된 메뉴 객체들의 요소를 프리미티브 타입으로 파일에 출력
		for (int i=0; i<orders.size(); i++) {
			orders.get(i).writeOrder(wo);
		}
	}
			
	// 저장된 테이블 객체 정보 입력
	void readOrder(DataInputStream ro) throws Exception{
		int orderSize = ro.readInt();	// 주문 메뉴 종류 수 
		// 반복을 통해 파일에 저장된 오더 객체 정보를 새로운 오더 객체를 생성하여 정보 입력 후 orders[]에 추가
		for (int i=0; i<orderSize; i++) {
			Order order = new Order();	// 오더 객체 생성
			order.readOrder(ro);	// 오더 정보 입력
			orders.add(order);	// 오더 배열에 추가
		}
	}
		
	// 테이블 객체를 파일에 출력
	void writeTable(DataOutputStream wt) throws Exception{
		wt.writeUTF(tableName);	// 테이블명을 파일에 출력
		wt.writeInt(member);	// 수용 가능 인원을 파일에 출력
		wt.writeBoolean(available);	// 이용 가능 여부를 파일에 출력
		writeOrder(wt);	// 오더 데이터를 파일에 출력
	}
		
	// 저장된 테이블 객체 정보 입력
	void readTable(DataInputStream rt) throws Exception{
		tableName = rt.readUTF();	// 파일에 저장된 테이블 명을 입력
		member = rt.readInt();	// 파일에 저장된 수용 가능 인원을 입력
		available = rt.readBoolean();	// 파일에 저장된 이용 가능 여부를 입력
		readOrder(rt);	// 파일에 오더 데이터를 입력
	}	
	
	// 직렬화
	void writeObject(ObjectOutputStream oop) throws Exception{
		oop.defaultWriteObject();	// 기본 객체 직렬화
		oop.writeObject(orders);	// orders 직렬화	
	}
	
	// 역직렬화
	void readObject(ObjectInputStream oip) throws Exception{
		oip.defaultReadObject();	// 기본 객체 역직렬화
		orders = (ArrayList<Order>) oip.readObject();	// orders 역직렬화
	}
	
    // equals() 함수 재정의
    public boolean equals(Object o) {
	    if (this == o) return true;
	    if (o == null || getClass() != o.getClass()) return false;

	    Table otherTable = (Table) o;

	    // 두 Table 객체의 tableName 필드를 비교하여 같으면 true 반환
	    return tableName.equals(otherTable.tableName);
	}
    
	// toString() 재정의
	public String toString() {
		return tableName+"("+member+"): " + available;
	}
}
