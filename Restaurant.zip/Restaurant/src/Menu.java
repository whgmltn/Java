import java.io.*;

// Menu 클래스
public class Menu implements Serializable{
	protected String menuName = "";	// 메뉴명 변수
	protected int price = 0;	// 메뉴 가격 변수
	
	//기본생성자
	Menu() {}
	
	//메뉴 생성자: 이름만 지정
	Menu(String menuName){
		this.menuName = menuName;
	}
	
	//메뉴 생성자: 이름과 가격을 지정하여 생성함
	Menu(String menuName, int price) {
		this.menuName = menuName;
		this.price = price;
	}
		
	// 메뉴명 접근자
	String getMenuName() {
		return menuName;	// 메뉴명 반환
	}
		
	// 메뉴 가격 접근자
	int getPrice() {
		return price;	//메뉴 가격 반환
	}
			
	// 메뉴명 설정자
	void setMenuName(String menuName) {
		this.menuName = menuName;
	}
		
	// 메뉴 가격 설정자
	void setPrice(int price) {
		this.price = price;
	}
	
	// 메뉴 객체를 파일에 출력
	void writeMenu(DataOutputStream wm) throws Exception{
		wm.writeUTF(menuName);	// 메뉴명을 파일에 출력
		wm.writeInt(price);	// 메뉴 비용을 파일에 출력
	}
	
	// 저장된 메뉴 객체 정보 입력
	void readMenu(DataInputStream rm) throws Exception{
		this.menuName = rm.readUTF();	// 파일에 저장된 메뉴명을 입력
		this.price = rm.readInt();	// 파일에 저장된 메뉴 가격을 입력
	}
		
	// equals() 함수 재정의   
	public boolean equals(Object o) {
	    if (this == o) return true;
	    if (o == null || getClass() != o.getClass()) return false;

	    Menu otherMenu = (Menu) o;

	    // 두 Menu 객체의 menuName 필드를 비교하여 같으면 true 반환
	    return menuName.equals(otherMenu.menuName);
	}

	
	// toString() 함수 재정의
	public String toString() {
		return menuName + " : " + price ;
	}
}
