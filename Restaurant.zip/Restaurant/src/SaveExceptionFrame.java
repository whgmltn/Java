import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import java.awt.GridBagLayout;
import java.awt.GridLayout;
import javax.swing.JTextField;
import java.awt.GridBagConstraints;
import javax.swing.JButton;
import java.awt.Insets;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.awt.event.ActionEvent;

public class SaveExceptionFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JLabel lblNewLabel;
	private JPanel panel;
	private JButton btnNewButton;
	private JButton btnNewButton_1;
	ObjectOutputStream out;
	Restaurant res;

	/**
	 * Create the frame.
	 */
	public SaveExceptionFrame(Restaurant getRes,ObjectOutputStream getOutput) {
		res = getRes;
		out = getOutput;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 300, 175);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{200, 0};
		gbl_contentPane.rowHeights = new int[]{69, 0, 0};
		gbl_contentPane.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{1.0, 0.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		lblNewLabel = new JLabel("저장 하시겠습니까?");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 0);
		gbc_lblNewLabel.gridx = 0;
		gbc_lblNewLabel.gridy = 0;
		contentPane.add(lblNewLabel, gbc_lblNewLabel);
		
		panel = new JPanel();
		GridBagConstraints gbc_panel = new GridBagConstraints();
		gbc_panel.fill = GridBagConstraints.BOTH;
		gbc_panel.gridx = 0;
		gbc_panel.gridy = 1;
		contentPane.add(panel, gbc_panel);
		panel.setLayout(new GridLayout(1, 0, 0, 0));
		
		btnNewButton = new JButton("예");
		btnNewButton.addActionListener(new ButtonListener());
		panel.add(btnNewButton);
		
		btnNewButton_1 = new JButton("아니요");
		btnNewButton_1.addActionListener(new ButtonListener());
		panel.add(btnNewButton_1);
	}
	
	//버튼 동작
	class ButtonListener implements ActionListener {

		public void actionPerformed(ActionEvent e) {
			if(e.getSource()==btnNewButton) {
				try {
					res.writeObject(out);	// 데이터들을 파일에 저장
				} catch (Exception e1) {
				}finally {
					try {
						out.close();	// 스트림 닫기
					} catch (IOException ioe) {}
				}
			}
			System.exit(0);
		}
	}

}

