import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTabbedPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.BoxLayout;
import java.awt.Font;
import javax.swing.table.DefaultTableModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.ListSelectionModel;
import java.awt.BorderLayout;

public class ResGUIpage1 extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;
	private JTable table_1;
	private JPanel panel;
	private JScrollPane scrollPane_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ResGUIpage1 frame = new ResGUIpage1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ResGUIpage1() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 944, 638);
		contentPane = new JPanel();

		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		contentPane.add(tabbedPane);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		tabbedPane.addTab("Table", null, scrollPane, null);
		
		String colNamesT[]= {"테이블 명","수용 인원","이용 가능 여부"};
		Object dataT[][]= {{"Table1",4,false},
				{"Table2",6,false},
				{"Table3",6,false},
				{"Table4",1,false},
				{"Table5",2,true},
				{"Table6",4,false},
				{"Table7",4,false},
				{"Table8",2,true},
				{"Table9",4,true}};
		
		table = new JTable(dataT, colNamesT);
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{"Table1", new Integer(4), Boolean.FALSE},
				{"Table2", new Integer(6), Boolean.FALSE},
				{"Table3", new Integer(6), Boolean.FALSE},
				{"Table4", new Integer(1), Boolean.FALSE},
				{"Table5", new Integer(2), Boolean.TRUE},
				{"Table6", new Integer(4), Boolean.FALSE},
				{"Table7", new Integer(4), Boolean.FALSE},
				{"Table8", new Integer(2), Boolean.TRUE},
				{"Table9", new Integer(4), Boolean.TRUE},
			},
			new String[] {
				"\uD14C\uC774\uBE14 \uBA85", "\uC218\uC6A9 \uC778\uC6D0", "\uC774\uC6A9 \uAC00\uB2A5 \uC5EC\uBD80"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, Integer.class, Boolean.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		table.setFillsViewportHeight(true);
		table.setCellSelectionEnabled(true);
		table.setFont(new Font("함초롬돋움", Font.PLAIN, 13));
		scrollPane.setViewportView(table);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		tabbedPane.addTab("Menu", null, scrollPane_1, null);
		
		String colNamesM[]= {"메뉴","수량","주문금액"};
		Object dataM[][]= {{"명란 크림 파스타",4,60000},
				{"마늘빵",6,18000},
				{"고르곤졸라 피자",1,17000},
				{"얼큰 해장 파스타",3,45000},
				{"콜라",4,12000},
				{"후식 아이스크림",4,8000}};
		
		table_1 = new JTable(dataM, colNamesM);
		scrollPane_1.setViewportView(table_1);
		
		panel = new JPanel();
		contentPane.add(panel, BorderLayout.NORTH);
		
		scrollPane_2 = new JScrollPane();
		panel.add(scrollPane_2);
	}

}
