import java.io.*;
import java.util.*;

public class User {
		
	public static void main(String args[]){
		User user = new User();
		Scanner input = new Scanner(System.in);	// 스캐너 객체 호출
		Restaurant bab = null;	// Restaurant 변수 생성
		ObjectInputStream in = null;	// DataInputStream 변수 생성
		String fileName = "restaurant.dat";	// 데이터 입출력할 파일명
		try {
			in = new ObjectInputStream(new FileInputStream(fileName));
			bab = new Restaurant(in);	// DataInputStream을 변수로 받는 Restaurant 객체 생성
		}
		catch(FileNotFoundException fnfe) {	// 처음 시작하는 경우 등 파일이 없을 때
			System.out.println("파일이 존재하지 않습니다. 첫 실행일 경우 숫자 '0'을 입력해주세요.");
			System.out.println("첫 실행이 아닌 경우 0을 제외한 아무 숫자를 입력해주시면 프로그램이 종료됩니다. 확인 후 재실행 해주시길 바랍니다.");
			int first = -1;
			try {
				first = input.nextInt();
			} catch(Exception e) {}
			// 첫 실행이 아닌데 파일 없음이 발생한 경우 프로그램 종료 
			if (first != 0) {
				System.exit(0);
			}
			bab = new Restaurant();	// 데이터를 불러오지 않는 기본 생성자 함수를 사용해 Restaurant 객체 생성
		}
		catch(Exception e) {	
			System.out.println("파일 읽기에 오류가 발생하였습니다.");
			bab = new Restaurant();	// 데이터를 불러오지 않는 기본 생성자 함수를 사용해 Restaurant 객체 생성
		} finally {
			try {
				in.close();	// 스트림 닫기
			} catch (Exception e) {}
		}
		ObjectOutputStream out = null;
		try {
			out = new ObjectOutputStream(new FileOutputStream("restaurant.dat"));	//"restaurant.dat" 파일에 저장할 예정
		} catch(Exception e){
			System.out.println("저장할 파일 불러오기에 오류가 있습니다.");
			try {
				out.close();
			} catch (IOException ioe) {}
		} 
		
		
		// while문을 통한 반복
		while(true) {
			ArrayList<Table> tables = bab.getTables();
			ArrayList<Menu> menus = bab.getMenus();
			System.out.println("무엇을 하시겠습니까?(선택지 번호로 입력해주세요.)");
			System.out.println("1.주문 관리, 2.메뉴 관리, 3.테이블 관리, 4.작업 저장, 5.종료");
			int what = -1;
			try {
				what = input.nextInt();
			} catch(InputMismatchException ime) {
				System.out.println("숫자만 입력하세요.");
				input.nextLine();
			} catch(Exception e) {
				System.out.println("오류가 발생했습니다.");
				input.nextLine();
			}
			// 메뉴와 테이블이 추가되지 않은 상태라면 먼저 추가하도록 함.
			if(what==1 && (bab.getTableSize() == 0 || bab.getMenuSize() == 0)) {
				System.out.println("메뉴와 테이블을 먼저 추가해주세요.");
				continue;
			}
			
			// 종료 선택 시 작업 저장 후 while문 종료 및 프로그램 종료
			if(what==5) {
				try {
					bab.writeObject(out);	// 데이터들을 파일에 저장
				} catch (Exception e) {
					System.out.println("파일 저장에 오류가 발생했습니다.");
					try {
						out.close();	// 스트림 닫기
					} catch (IOException ioe) {}
				}
				break;
			}
			
			// 선택에 따른 반복을 위해 switch문 사용
			switch(what) {
				case 1:	//주문관리
					System.out.println("1. 주문 추가, 2. 주문 내역 확인, 3. 계산");
					int what1 = -1;
					try {
						what1 = input.nextInt();
					} catch(InputMismatchException ime) {
						System.out.println("숫자만 입력하세요.");
						input.nextLine();
					} catch(Exception e) {
						System.out.println("오류가 발생했습니다.");
						input.nextLine();
					}
					//주문 추가
					if (what1==1) {
						user.table(bab);
						System.out.println("어느 테이블입니까?");
						int table = -1;
						try {
							table = input.nextInt();
						} catch(InputMismatchException ime) {
							System.out.println("숫자만 입력하세요.");
							input.nextLine();
						} catch(Exception e) {
							System.out.println("오류가 발생했습니다.");
							input.nextLine();
						}
						// 0보다 작거나 테이블 수보다 큰 수의 배열 인덱스에 테이블이 존재하지 않으므로 나감.
						if(table<0 || table>=bab.getTableSize()) {
							System.out.println("테이블이 존재하지 않습니다.");
							break;
						}
						user.menu(bab); // 메뉴판
						System.out.println("주문하실 메뉴를 선택해주세요.");
						int order = -1;
						try {
							order = input.nextInt();
						} catch(InputMismatchException ime) {
							System.out.println("숫자만 입력하세요.");
							input.nextLine();
						} catch(Exception e) {
							System.out.println("오류가 발생했습니다.");
							input.nextLine();
						}
						// 0보다 작거나 메뉴 수보다 큰 수의 배열 인덱스에 메뉴가 존재하지 않으므로 나감.
						if(order<0 || order>=bab.getMenuSize()) {
							System.out.println("메뉴가 존재하지 않습니다.");
							break;
						}
						System.out.println("몇 개 주문하시겠습니까?");
						int orderN = -1;
						try {
							orderN = input.nextInt();
						} catch(InputMismatchException ime) {
							System.out.println("숫자만 입력하세요.");
							input.nextLine();
						} catch(Exception e) {
							System.out.println("오류가 발생했습니다.");
							input.nextLine();
						}	
						if(orderN <1) {
							System.out.println("메뉴는 1개 이상부터 주문할 수 있습니다.");
							break;
						}
						tables.get(table).inTable();
						Order ord = bab.menuToOrder(menus.get(order));
						tables.get(table).addOrder(ord, orderN);
					}	
					// 주문 내역 확인
					else if (what1==2) {
						user.table(bab);	// 테이블 리스트
						System.out.println("어느 테이블입니까?");
						int table = -1;
						try {
							table = input.nextInt();
						} catch(InputMismatchException ime) {
							System.out.println("숫자만 입력하세요.");
							input.nextLine();
						} catch(Exception e) {
							System.out.println("오류가 발생했습니다.");
							input.nextLine();
						}
						// 0보다 작거나 테이블 수보다 큰 수의 배열 인덱스에 테이블이 존재하지 않으므로 나감.
						if(table<0 || table>=bab.getTableSize()) {
							System.out.println("테이블이 존재하지 않습니다.");
							break;
						}
						user.order(tables.get(table));	// 해당 테이블의 주문 내역
					}
					// 계산
					else if (what1==3) {
						user.table(bab);	// 테이블 리스트
						System.out.println("어느 테이블입니까?");
						int table = -1;
						try {
							table = input.nextInt();
						} catch(InputMismatchException ime) {
							System.out.println("숫자만 입력하세요.");
							input.nextLine();
						} catch(Exception e) {
							System.out.println("오류가 발생했습니다.");
							input.nextLine();
						}
						// 0보다 작거나 테이블 수보다 큰 수의 배열 인덱스에 테이블이 존재하지 않으므로 나감.
						if(table<0 || table>=bab.getTableSize()) {
							System.out.println("테이블이 존재하지 않습니다.");
							break;
						}
						int paid = bab.pay(tables.get(table));
						System.out.println(paid+"가 결제 되었습니다.");
					}
					break;
					
				case 2:	// 메뉴 관리
					System.out.println("1. 메뉴 추가, 2. 메뉴 삭제, 3. 메뉴 리스트 보기");
					int what2 = -1;
					try {
						what2 = input.nextInt();
					} catch(InputMismatchException ime) {
						System.out.println("숫자만 입력하세요.");
						input.nextLine();
					} catch(Exception e) {
						System.out.println("오류가 발생했습니다.");
						input.nextLine();
					}
					// 메뉴 추가
					if (what2==1) {
						input.nextLine();
						System.out.println("추가하실 메뉴의 이름을 입력하세요.");	
						String menuName = input.nextLine();	// 메뉴명 입력 받음
						System.out.println("추가하실 메뉴의 가격을 입력하세요.");
						int menuPrice = -1;	
						try {
							menuPrice = input.nextInt();	// 메뉴 가격 입력 받음
						} catch(InputMismatchException ime) {
							System.out.println("숫자만 입력하세요.");
							input.nextLine();
						} catch(Exception e) {
							System.out.println("오류가 발생했습니다.");
							input.nextLine();
						}
						if (menuPrice<0) {
							System.out.println("메뉴 가격은 0원 이상이어야 합니다.");
							break;
						}
						try {
							bab.addMenu(new Menu(menuName, menuPrice));	// 메뉴 객체 생성 후 식당 메뉴에 추가
							System.out.println("\'"+menuName+"\'"+"(이/가) 추가되었습니다.");
						} catch (Exception e) {	
							System.out.println(e.getMessage());
						}
					}
					// 메뉴 삭제
					else if (what2==2) {
						input.nextLine();
						System.out.println("삭제하실 메뉴의 이름을 입력하세요.");	
						String menuName = input.nextLine();	// 메뉴명 입력 받음
						try {
							bab.deleteMenu(new Menu(menuName));	// 코드와 이름을 부여받은 임의의 메뉴 객체를 생성하여 같은 메뉴 객체가 있다면 삭제
							System.out.println(menuName+"이 삭제되었습니다.");
						} catch (Exception e) {	
							System.out.println(e.getMessage());
						}
					}
					// 메뉴 리스트 확인
					else if (what2==3) {
						user.menu(bab);	// 메뉴판
					}
					break;
					
				case 3:	// 테이블 관리
					System.out.println("1. 테이블 추가, 2. 테이블 삭제, 3. 테이블 리스트 보기");
					int what3 = -1;	
					try {
						what3= input.nextInt();
					} catch(InputMismatchException ime) {
						System.out.println("숫자만 입력하세요.");
						input.nextLine();
					} catch(Exception e) {
						System.out.println("오류가 발생했습니다.");
						input.nextLine();
					}
					// 테이블 추가
					if (what3==1) {
						input.nextLine();
						System.out.println("추가하실 테이블의 이름을 입력하세요.");	
						String tableName = input.nextLine();	// 테이블명 입력 받음
						System.out.println("추가하실 테이블의 수용 가능 인원을 입력하세요.");	
						int member = -1;	
						try {
							member = input.nextInt();	// 수용 가능 인원 입력 받음
						} catch(InputMismatchException ime) {
							System.out.println("숫자만 입력하세요.");
							input.nextLine();
						} catch(Exception e) {
							System.out.println("오류가 발생했습니다.");
							input.nextLine();
						}
						if (member<1) {
							System.out.println("수용 가능 인원은 1명 이상이어야 합니다.");
							break;
						}
						System.out.println("추가하실 테이블의 이용 가능 여부를 입력하세요.(true/false)");	
						boolean available = false;	
						try {
							available = input.nextBoolean();	// 이용 가능 여부 입력 받음
						} catch(InputMismatchException ime) {
							System.out.println("true 또는 false 이외의 값이 들어와 이용 가능 상태로 설정됩니다.");
							input.nextLine();
						} catch(Exception e) {
							System.out.println("오류가 발생하여 이용 가능 상태로 설정됩니다.");
							input.nextLine();
						}
						try {
							bab.addTable(new Table(tableName, member, available));	// 테이블 객체 생성 후 식당 테이블에 추가
							System.out.println(tableName+" 테이블이 추가되었습니다.");
						} catch (Exception e) {	
							System.out.println(e.getMessage());
						}
					}
					// 테이블 삭제
					else if (what3==2) {
						input.nextLine();
						System.out.println("삭제하실 테이블의 이름을 입력하세요.");	
						String tableName = input.nextLine();	// 테이블명 입력 받음
						try {
							bab.deleteTable(new Table(tableName));	// 이름을 부여받은 임의의 테이블 객체 생성 후 같은 이름의 테이블 객체 있다면 삭제
							System.out.println(tableName+" 테이블이 삭제되었습니다.");
						} catch (Exception e) {	
							System.out.println(e.getMessage());
						}
					}
					// 테이블 리스트 확인
					else if (what3==3) {
						user.table(bab);
					}
					break;	
				
				// 작업 저장 선택 시 파일에 데이터 저장
				case 4:
					try {
						bab.writeObject(out);	// 데이터들을 파일에 저장
					} catch (Exception e) {
						System.out.println("파일 저장에 오류가 발생했습니다.");
						try {
							out.close();	// 스트림 닫기
						} catch (IOException ioe) {}
					}
					break;
					
				// 5가지 선택지 이외의 선택을 한 경우 switch 문을 빠져나가 while문 반복을 통해 선택지를 다시 입력하도록 함.
				default:
					System.out.println("선택지를 벗어났습니다. 다시 시도하세요.");
					break;
			}
						
		}
		System.out.println("매출: "+ bab.getAmount());	// 총매출 출력
		System.out.println("프로그램을 종료합니다.");	
		try {
			out.close();
		} catch (IOException e) {}
		input.close();	// 스캐너 닫음
	}
	
	// menu판 함수
	public void menu(Restaurant r) {
		ArrayList<Menu> menus= r.getMenus();
		String menu = "----------메뉴판----------\n";
		//반복문을 사용해 식당의 메뉴를 menu 변수에 추가
		for(int i=0; i<r.getMenuSize(); i++) {
			if (menus.get(i) != null) {
				menu += i +". "+ menus.get(i)+"원";
			}
			else {
				break;
			}
			menu += "\n";
		}
		System.out.println(menu);
	}
	
	// table 나열 함수
	public void table(Restaurant r) {
		ArrayList<Table> tables= r.getTables();
		String table = "----------테이블----------\n";
		//반복문을 사용해 식당의 메뉴를 table 변수에 추가
		for(int i=0; i<r.getTableSize(); i++) {
			if (tables.get(i) != null) {
				table += i +". "+ tables.get(i)+ "[주문금액: "+tables.get(i).getTotal()+"]";
			}
			else {
				break;
			}
			table += "\n";
		}
		System.out.println(table);
	}
	
	// table 나열 함수
	public void order(Table t) {
		ArrayList<Order> orders= t.getOrders();
		String order = "----------주문내역----------\n";
		//반복문을 사용해 식당의 메뉴를 table 변수에 추가
		for(int i=0; i<t.getOrderSize(); i++) {
			if (orders.get(i) != null) {
				order += i +". "+ orders.get(i)+"개";
				}
			else {
				break;
			}
			order += "\n";
		}
		order += "------------------------\n";
		order += "주문금액: " + t.getTotal();
		System.out.println(order);
	}
	
	
}
