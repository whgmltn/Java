import java.io.*;

// Order 클래스(메뉴 클래스를 상속)
public class Order extends Menu implements Serializable{
	private int orderCount;	// 메뉴 주문량
	
	// 기본 생성자
	Order(){}
	
	// 오더 생성자
	Order(String menuName, int price) {
		super(menuName, price);
		orderCount =0;
	}
	
	// 메뉴 주문량 접근자
	int getOrderCount() {
		return orderCount;
	}
	
	// 메뉴 주문량 설정자
	void setOrderCount(int orderCount) {
		this.orderCount = orderCount;
	}
	
	// 메뉴 주문량 추가 함수
	void addOrderCount(int n) {
		orderCount += n;
	}
		
	// 메뉴 주문량 감소 함수
	void minusOrderCount(int n) {
		if (orderCount > n) {
			orderCount -= n;
		}
	}
	
	// 메뉴의 주문 금액
	int getOrderPay() {
		return price * orderCount;
	}
	
	
	
	// 직렬화
	private void writeObject(ObjectOutputStream out) throws Exception {
		out.writeUTF(menuName);	// 메뉴명(슈퍼클래스 필드값)
		out.writeInt(price);	// 메뉴 가격(슈퍼클래스 필드값)
		out.writeInt(orderCount);	// 주문량
	}
	
	// 역직렬화
	private void readObject(ObjectInputStream in) throws Exception{
		menuName = in.readUTF();	// 메뉴명(슈퍼클래스 필드값)
		price = in.readInt();	// 메뉴 가격(슈퍼클래스 필드값)
		orderCount = in.readInt();	// 주문량
	}
	
	// 오더 객체를 파일에 출력
	void writeOrder(DataOutputStream wo) throws Exception{
		wo.writeUTF(menuName);	// 메뉴명을 파일에 출력
		wo.writeInt(price);	// 메뉴 가격을 파일에 출력
		wo.writeInt(orderCount);	// 메뉴 주문 횟수를 파일에 출력
	}
			
	// 저장된 오더 객체 정보 입력
	void readOrder(DataInputStream ro) throws Exception{
		menuName = ro.readUTF();	// 파일에 저장된 메뉴 명을 입력
		price = ro.readInt();	// 파일에 저장된 메뉴 가격을 입력
		orderCount = ro.readInt();	// 파일에 저장된 메뉴 주문 횟수를 입력
	}
		
    // equals() 함수 재정의
	public boolean equals(Object o) {
	    if (this == o) return true;
	    if (o == null || getClass() != o.getClass()) return false;

	    Order otherOrder = (Order) o;

	    // 두 Order 객체의 menuName 필드를 비교하여 같으면 true 반환
	    return menuName.equals(otherOrder.menuName);
	}
    
	// toString() 함수 재정의
	public String toString() {
		return menuName + " : " + price + " / " +orderCount;
	}
}
