import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;

import java.awt.ScrollPane;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.GridLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.JList;
import javax.swing.ScrollPaneConstants;
import javax.swing.SpinnerNumberModel;
import javax.swing.JTable;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

import java.awt.Label;
import javax.swing.JTextField;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.Button;
import java.io.*;
import java.util.*;

public class ResGui extends JFrame {

	private static final long serialVersionUID = 1L;
	private JTable table;
	private JTable table_1;
	private JSpinner spinner;
	private JTextField textField;
	private ObjectOutputStream out;
	private ObjectInputStream in;
	private Restaurant bab;
	private ArrayList<Menu> menus;
	private ArrayList<Table> tables;
	private JButton selectedButton;
	private Table selectedTable;
	private DefaultTableModel selectedOrderModel;
	private JButton selectedMenuButton;
	private Label label;
	private JLabel label_1;
	private JButton button;
	private Menu addMenu;
	private GridBagConstraints gbc_textField;
	private JPanel panel;
	JButton btnNewButton_1;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ResGui frame = new ResGui();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ResGui() {
		String fileName = "restaurant.dat";	// 데이터 입출력할 파일명
		try {
			in = new ObjectInputStream(new FileInputStream(fileName));
			bab = new Restaurant(in);	// ObjectInputStream을 변수로 받는 Restaurant 객체 생성
		}
		catch(FileNotFoundException fnfe) {	// 처음 시작하는 경우 등 파일이 없을 때
			bab = new Restaurant();	// 데이터를 불러오지 않는 기본 생성자 함수를 사용해 Restaurant 객체 생성
		}
		catch(Exception e1) {	
			bab = new Restaurant();	// 데이터를 불러오지 않는 기본 생성자 함수를 사용해 Restaurant 객체 생성
		} finally {
			try {
				in.close();	// 스트림 닫기
			} catch (Exception e1) {}
		}		
		tables = bab.getTables();
		menus = bab.getMenus();
		
		// 윈도우 리스너 객체 생성
        MyWindowListener listener = new MyWindowListener();
        // 윈도우에 리스너 등록
        addWindowListener(listener);
		
		setTitle("Restaurant");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1025, 564);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[] {696, 0};
		gridBagLayout.rowHeights = new int[] {20, 287, 28, 129, 5};
		gridBagLayout.columnWeights = new double[]{1.0, 1.0};
		gridBagLayout.rowWeights = new double[]{0.0, 1.0, 0.0, 1.0, Double.MIN_VALUE};
		getContentPane().setLayout(gridBagLayout);
		
		JLabel lblNewLabel = new JLabel("Table");
		lblNewLabel.setFont(new Font("함초롬돋움", Font.BOLD, 15));
		lblNewLabel.setHorizontalAlignment(SwingConstants.LEFT);
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.gridx = 0;
		gbc_lblNewLabel.gridy = 0;
		getContentPane().add(lblNewLabel, gbc_lblNewLabel);
		
		JLabel lblNewLabel_2 = new JLabel("Order");
		lblNewLabel_2.setFont(new Font("함초롬돋움", Font.BOLD, 15));
		GridBagConstraints gbc_lblNewLabel_2 = new GridBagConstraints();
		gbc_lblNewLabel_2.insets = new Insets(0, 0, 5, 0);
		gbc_lblNewLabel_2.gridx = 1;
		gbc_lblNewLabel_2.gridy = 0;
		getContentPane().add(lblNewLabel_2, gbc_lblNewLabel_2);
		
		JScrollPane scrollPane = new JScrollPane();
		lblNewLabel.setLabelFor(scrollPane);
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		GridBagConstraints gbc_scrollPane = new GridBagConstraints();
		gbc_scrollPane.insets = new Insets(0, 0, 5, 5);
		gbc_scrollPane.fill = GridBagConstraints.BOTH;
		gbc_scrollPane.gridx = 0;
		gbc_scrollPane.gridy = 1;
		getContentPane().add(scrollPane, gbc_scrollPane);
		
		JPanel panel_1 = new JPanel();
		scrollPane.setViewportView(panel_1);
		panel_1.setLayout(new GridLayout(3, 3, 1, 0));
		
		int tableSize = bab.getTableSize();
		for (int i=0; i<tableSize; i++) {
			Table t = tables.get(i);
			JButton btnNewButton = new JButton("<html>"+t.getTableName()+" &ensp; ["+t.getMember()+"인]<br><hr>합계: "+t.getTotal()+"원</html>");
			btnNewButton.setHorizontalAlignment(SwingConstants.LEFT);
			btnNewButton.setFont(new Font("함초롬돋움", Font.BOLD, 14));
			//테이블 이용 손님 없을 때
			if(t.getAvailable()==true) {
				btnNewButton.setBackground(Color.WHITE);
			}
			
			// 주문 내역
			ArrayList<Order> orders = t.getOrders();
			int orderSize = t.getOrderSize();
			DefaultTableModel orderModel = new DefaultTableModel(new Object[][] {},new String[] {"메뉴","수량","주문금액"}){
				Class[] columnTypes = new Class[] {
						String.class, Integer.class, Integer.class
					};
					public Class getColumnClass(int columnIndex) {
						return columnTypes[columnIndex];
					}
					public boolean isCellEditable(int row, int column) {
				        return false; // 셀을 편집하지 못하도록 설정
				    }
				};
			
				
			for(int j=0; j<orderSize; j++) {
				Order o = orders.get(j);
				orderModel.addRow(new Object[]{o.getMenuName(), o.getOrderCount(), o.getOrderPay()});
			}
			
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(selectedButton != null) {
						if(selectedTable.getAvailable()==true) {
							selectedButton.setBackground(Color.WHITE);
						}else {
							selectedButton.setBackground(null);
						}
						btnNewButton_1.setVisible(false);
					}
					selectedButton = btnNewButton;
					selectedButton.setBackground(Color.lightGray);
					lblNewLabel_2.setText("Order - "+ t.getTableName());	// 주문 내역 위에 'Order - table1' 이렇게 뜨도록
					table_1.setModel(orderModel);
					selectedTable = t;
					selectedOrderModel = orderModel;
					label.setText("합계: "+ t.getTotal()+"원");
					if(selectedTable.getAvailable() == true) {
						btnNewButton_1.setVisible(true);
					}
				}
			});
			panel_1.add(btnNewButton);
		}
		
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane_1.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		lblNewLabel_2.setLabelFor(scrollPane_1);
		GridBagConstraints gbc_scrollPane_1 = new GridBagConstraints();
		gbc_scrollPane_1.insets = new Insets(0, 0, 5, 0);
		gbc_scrollPane_1.fill = GridBagConstraints.BOTH;
		gbc_scrollPane_1.gridx = 1;
		gbc_scrollPane_1.gridy = 1;
		getContentPane().add(scrollPane_1, gbc_scrollPane_1);
		
		table_1 = new JTable();
		table_1.setRowSelectionAllowed(false);
		table_1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table_1.setFont(new Font("함초롬돋움", Font.PLAIN, 13));
		scrollPane_1.setViewportView(table_1);
		
		JLabel lblNewLabel_1 = new JLabel("Menu");
		lblNewLabel_1.setFont(new Font("함초롬돋움", Font.BOLD, 15));
		GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
		gbc_lblNewLabel_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_1.gridx = 0;
		gbc_lblNewLabel_1.gridy = 2;
		getContentPane().add(lblNewLabel_1, gbc_lblNewLabel_1);
        
		JPanel panel_checkIn = new JPanel();
		GridBagConstraints gbc_panel_checkIn = new GridBagConstraints();
		gbc_panel_checkIn.fill = GridBagConstraints.HORIZONTAL;
		gbc_panel_checkIn.gridx = 1;
		gbc_panel_checkIn.gridy = 2;
		getContentPane().add(panel_checkIn, gbc_panel_checkIn);
		GridBagLayout gbl_panel_checkIn = new GridBagLayout();
		gbl_panel_checkIn.columnWidths = new int[]{0, 0, 0};
		gbl_panel_checkIn.rowHeights = new int[]{22, 0};
		gbl_panel_checkIn.columnWeights = new double[]{0.0, 1.0, Double.MIN_VALUE};
		gbl_panel_checkIn.rowWeights = new double[]{0.0, Double.MIN_VALUE};
		panel_checkIn.setLayout(gbl_panel_checkIn);
		
		btnNewButton_1 = new JButton("입장하기");
		btnNewButton_1.setVisible(false);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				selectedTable.inTable();
				selectedButton.setText("<html>"+selectedTable.getTableName()+" &ensp; ["+selectedTable.getMember()+"인]<br><hr>합계: "+selectedTable.getTotal()+"원</html>");			
				btnNewButton_1.setVisible(false);
			}
		});
		btnNewButton_1.setFont(new Font("함초롬돋움", Font.PLAIN, 12));
		GridBagConstraints gbc_btnNewButton_1 = new GridBagConstraints();
		gbc_btnNewButton_1.fill = GridBagConstraints.BOTH;
		gbc_btnNewButton_1.insets = new Insets(0, 0, 0, 5);
		gbc_btnNewButton_1.gridx = 0;
		gbc_btnNewButton_1.gridy = 0;
		panel_checkIn.add(btnNewButton_1, gbc_btnNewButton_1);
		
		label = new Label();
		label.setAlignment(Label.RIGHT);
		label.setForeground(new Color(0, 0, 0));
		GridBagConstraints gbc_label = new GridBagConstraints();
		gbc_label.anchor = GridBagConstraints.NORTHWEST;
		gbc_label.insets = new Insets(0, 0, 0, 5);
		gbc_label.fill = GridBagConstraints.HORIZONTAL;
		gbc_label.gridx = 1;
		gbc_label.gridy = 0;
		panel_checkIn.add(label, gbc_label);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		lblNewLabel_1.setLabelFor(scrollPane_2);
		scrollPane_2.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane_2.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		GridBagConstraints gbc_scrollPane_2 = new GridBagConstraints();
		gbc_scrollPane_2.insets = new Insets(0, 0, 0, 5);
		gbc_scrollPane_2.fill = GridBagConstraints.BOTH;
		gbc_scrollPane_2.gridx = 0;
		gbc_scrollPane_2.gridy = 3;
		getContentPane().add(scrollPane_2, gbc_scrollPane_2);
		
		JPanel panel_3 = new JPanel();
		scrollPane_2.setViewportView(panel_3);
		panel_3.setLayout(new GridLayout(0, 5, 1, 0));
		
		int menuSize = bab.getMenuSize();
		for (int i=0; i<menuSize; i++) {
			Menu m = menus.get(i);
			JButton btnNewButton = new JButton("<html>"+m.getMenuName()+"<br>"+m.getPrice()+"원</html>");
			btnNewButton.setFont(new Font("함초롬돋움", Font.PLAIN, 12));
			btnNewButton.addMouseListener(new MyMouseListener(m));
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(selectedMenuButton != null) {
						selectedMenuButton.setBackground(null);
					}
					selectedMenuButton = btnNewButton;
					addMenu = m;
				}
			});
			panel_3.add(btnNewButton);
		}
		
		panel = new JPanel();
		GridBagConstraints gbc_panel = new GridBagConstraints();
		gbc_panel.fill = GridBagConstraints.BOTH;
		gbc_panel.gridx = 1;
		gbc_panel.gridy = 3;
		getContentPane().add(panel, gbc_panel);
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWidths = new int[] {0, 0, 0, 0, 0};
		gbl_panel.rowHeights = new int[] {0, 0};
		gbl_panel.columnWeights = new double[]{0.0, 0.0, 1.0, 0.0, 0.0};
		gbl_panel.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0};
		panel.setLayout(gbl_panel);
		
		label_1 = new JLabel("주문 추가");
		label_1.setFont(new Font("함초롬돋움", Font.PLAIN, 12));
		label_1.setHorizontalAlignment(SwingConstants.RIGHT);
		GridBagConstraints gbc_label_1 = new GridBagConstraints();
		gbc_label_1.insets = new Insets(0, 0, 5, 5);
		gbc_label_1.anchor = GridBagConstraints.EAST;
		gbc_label_1.fill = GridBagConstraints.VERTICAL;
		gbc_label_1.gridx = 1;
		gbc_label_1.gridy = 1;
		panel.add(label_1, gbc_label_1);
		
		textField = new JTextField();
		textField.setText("수량");
		textField.setEditable(false);
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		label_1.setLabelFor(spinner);
		gbc_textField = new GridBagConstraints();
		gbc_textField.insets = new Insets(0, 0, 5, 5);
		gbc_textField.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField.gridx = 2;
		gbc_textField.gridy = 1;
		SpinnerNumberModel spinnerModel = new SpinnerNumberModel(0,0,100,1);
		spinner = new JSpinner(spinnerModel);
		spinner.setEnabled(false);
		panel.add(spinner, gbc_textField);
		
		button = new JButton("추가");
		button.setEnabled(false);
		button.addActionListener(new ButtonListener());
		button.setFont(new Font("함초롬돋움", Font.PLAIN, 12));
		GridBagConstraints gbc_button = new GridBagConstraints();
		gbc_button.insets = new Insets(0, 0, 5, 5);
		gbc_button.gridx = 3;
		gbc_button.gridy = 1;
		panel.add(button, gbc_button);
		
		JButton btnNewButton_23 = new JButton("계산");
		btnNewButton_23.setFont(new Font("함초롬돋움", Font.PLAIN, 14));
		btnNewButton_23.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(selectedTable == null || selectedTable.getAvailable() == true) {
					return;
				}
				CheckFrame payFrame = new CheckFrame(bab,selectedTable);
				payFrame.setLocationRelativeTo(ResGui.this);
				payFrame.setVisible(true);
				payFrame.addWindowListener(new WindowAdapter() {
					public void windowClosed(WindowEvent e) {
	                	if(selectedTable.getAvailable()==false) {
	                		return;
	                	}
	                	selectedButton.setText("<html>"+selectedTable.getTableName()+" &ensp; ["+selectedTable.getMember()+"인]<br><hr>합계: "+selectedTable.getTotal()+"원</html>");
	                	lblNewLabel_2.setText("Order");
	                	label.setText("합계: "+ selectedTable.getTotal()+"원");
	    				selectedOrderModel.setRowCount(0);
	    				selectedOrderModel.fireTableDataChanged();
	    				selectedButton.setBackground(Color.WHITE);
	    				selectedButton = null;
	    				selectedTable = null;
	    				selectedOrderModel = null;
	                }
				});
			}
		
		});
		GridBagConstraints gbc_btnNewButton_23 = new GridBagConstraints();
		gbc_btnNewButton_23.fill = GridBagConstraints.HORIZONTAL;
		gbc_btnNewButton_23.insets = new Insets(0, 0, 5, 5);
		gbc_btnNewButton_23.gridx = 2;
		gbc_btnNewButton_23.gridy = 2;
		panel.add(btnNewButton_23, gbc_btnNewButton_23);
		
		Button button_1 = new Button("관리자 모드");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					out = new ObjectOutputStream(new FileOutputStream(fileName));	//"restaurant.dat" 파일에 저장할 예정
					bab.writeObject(out);	// 데이터들을 파일에 저장
				} catch(Exception e1){
					ExceptionFrame ef = new ExceptionFrame(e1);
					ef.setLocationRelativeTo(ResGui.this);
					ef.setVisible(true);
				} finally {
				    try {
				        if (out != null) {
				            out.close();
				        }
				    } catch (IOException ioe) {
				    	ExceptionFrame ef = new ExceptionFrame(ioe);
						ef.setLocationRelativeTo(ResGui.this);
						ef.setVisible(true);
				        // 예외 처리
				    }
				}
				ResGui.this.dispose();
				ResGUIpage2 managerMode = new ResGUIpage2();
				managerMode.setVisible(true);
			}
		});
		button_1.setFont(new Font("함초롬돋움", Font.BOLD, 10));
		GridBagConstraints gbc_button_1 = new GridBagConstraints();
		gbc_button_1.insets = new Insets(0, 0, 0, 5);
		gbc_button_1.gridx = 3;
		gbc_button_1.gridy = 4;
		panel.add(button_1, gbc_button_1);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setEnabled(false);
		setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("File");
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmNewMenuItem_1 = new JMenuItem("저장");
		mntmNewMenuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					out = new ObjectOutputStream(new FileOutputStream(fileName));	//"restaurant.dat" 파일에 저장할 예정
					bab.writeObject(out);	// 데이터들을 파일에 저장
				} catch(Exception e1){
					ExceptionFrame ef = new ExceptionFrame(e1);
					ef.setLocationRelativeTo(ResGui.this);
					ef.setVisible(true);
				} finally {
				    try {
				        if (out != null) {
				            out.close();
				        }
				    } catch (IOException ioe) {
				    	ExceptionFrame ef = new ExceptionFrame(ioe);
						ef.setLocationRelativeTo(ResGui.this);
						ef.setVisible(true);
				        // 예외 처리
				    }
				}
			}
		});
		mnNewMenu.add(mntmNewMenuItem_1);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("종료");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ResGui.this.dispatchEvent(new WindowEvent(ResGui.this,WindowEvent.WINDOW_CLOSING));
			}
		});
		mnNewMenu.add(mntmNewMenuItem);
	}

	class MyWindowListener extends WindowAdapter{
		private SaveExceptionFrame saveFrame; // SaveExcepitonFrame 객체 참조 변수

	    public MyWindowListener() {
	    	try {
				out = new ObjectOutputStream(new FileOutputStream("restaurant.dat"));	//"restaurant.dat" 파일에 저장할 예정
			} catch(Exception e1){
				try {
					out.close();
				} catch (IOException ioe) {}
			}
			saveFrame = new SaveExceptionFrame(bab,out); // 생성자에서 SaveExcepitonFrame 객체 초기화
	    }

	    public void windowClosing(WindowEvent e) {
	    	setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
	        saveFrame.setLocationRelativeTo(ResGui.this);
	        saveFrame.addWindowListener(new WindowAdapter() {
                public void windowClosed(WindowEvent e) {
                    ResGui.this.dispose(); // ResGUIpage2 윈도우를 닫음
                }
            });
	        saveFrame.setVisible(true); // 윈도우가 닫힐 때 SaveExcepitonFrame을 보이도록 함
	        
	    }
	}
	
	class ButtonListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == button) {
				// 추가 누르면 텍스트 필드에 입력된 값 가져와서 그만큼 수량 추가
				selectedTable.inTable();
				int orderNum = (int)spinner.getValue();
				Order ord = bab.menuToOrder(addMenu);
				int ordIndex = selectedTable.searchOrder(ord);
				if(ordIndex != -1) {
					ord = selectedTable.getOrders().get(ordIndex);
					selectedTable.addOrder(ord, orderNum);
					selectedOrderModel.setValueAt(ord.getOrderCount(), ordIndex, 1);
					selectedOrderModel.setValueAt(ord.getOrderPay(), ordIndex, 2);
				}else {
					selectedTable.addOrder(ord, orderNum);
					selectedOrderModel.addRow(new Object[]{ord.getMenuName(), ord.getOrderCount(), ord.getOrderPay()});
				}
				selectedButton.setText("<html>"+selectedTable.getTableName()+" &ensp; ["+selectedTable.getMember()+"인]<br><hr>합계: "+selectedTable.getTotal()+"원</html>");
				label.setText("합계: "+ selectedTable.getTotal()+"원");
				selectedOrderModel.fireTableDataChanged();
				selectedMenuButton.setBackground(null);
				selectedMenuButton = null;
				spinner.setValue(0);
				spinner.setEnabled(false);
				button.setEnabled(false);
				btnNewButton_1.setVisible(false);
			}
		}
	}
	
	class MyMouseListener extends MouseAdapter{
		
		public MyMouseListener(Menu m) {
	        addMenu = m;
	    }
		
		public void mouseClicked(MouseEvent e) {
			if (e.getClickCount() == 2) {
				if (selectedTable ==null) {
					return;
				}
				spinner.setEnabled(false);
				button.setEnabled(false);
				selectedMenuButton.setBackground(null);
				Order ord = bab.menuToOrder(addMenu);
				int ordIndex = selectedTable.searchOrder(ord);
				if(ordIndex != -1) {
					ord = selectedTable.getOrders().get(ordIndex);
					selectedTable.addOrder(ord, 1);
					selectedOrderModel.setValueAt(ord.getOrderCount(), ordIndex, 1);
					selectedOrderModel.setValueAt(ord.getOrderPay(), ordIndex, 2);
				}else {
					selectedTable.addOrder(ord, 1);
					selectedOrderModel.addRow(new Object[]{ord.getMenuName(), ord.getOrderCount(), ord.getOrderPay()});
				}
				selectedButton.setText("<html>"+selectedTable.getTableName()+" &ensp; ["+selectedTable.getMember()+"인]<br><hr>합계: "+selectedTable.getTotal()+"원</html>");
				label.setText("합계: "+ selectedTable.getTotal()+"원");
				btnNewButton_1.setVisible(false);
				selectedOrderModel.fireTableDataChanged();
				
			}
			else if (e.getClickCount()==1) {
				if (selectedTable ==null) {
					return;
				}
//				textField.setVisible(false);
//				spinner.setVisible(true);
//				panel.add(spinner, gbc_textField);
				spinner.setEnabled(true);
				button.setEnabled(true);
				selectedMenuButton.setBackground(Color.lightGray);
			}
		}
	}	
	
}
